package agentic

import (
	"fmt"
	"testing"
)

// reviewerProbe drives scanSingleSource directly with one synthetic file.
// It is compiled unchanged into every tree under review.
func reviewerProbe(t *testing.T, label, src string) {
	t.Helper()
	vs, err := scanSingleSource(
		map[string]string{"pkg/launcher/probe.go": src},
		map[string]bool{"pkg/agentic/registry.go": true},
	)
	if err != nil {
		fmt.Printf("PROBE %-12s -> PARSE ERROR: %v\n", label, err)
		return
	}
	if len(vs) == 0 {
		fmt.Printf("PROBE %-12s -> UNCAUGHT\n", label)
		return
	}
	for _, v := range vs {
		fmt.Printf("PROBE %-12s -> CAUGHT: %s\n", label, v)
	}
}

const probeHead = `package launcher

import "strings"

var _ = strings.TrimSpace

type SystemID = string

type System interface{ ID() SystemID }

`

func TestReviewerProbes(t *testing.T) {
	cases := []struct{ label, body string }{
		// ---- rev2 B-probes, my exact spellings ----
		{"B1", `func argv(sys System) string {
	if id := sys.ID(); true {
		switch id {
		case "some-future-harness":
			return "a"
		}
	}
	return ""
}`},
		{"B2", `func argv(sys System) string {
	raw := sys.ID()
	id := raw
	switch id {
	case "some-future-harness":
		return "a"
	}
	return ""
}`},
		{"B3", `func argv(sys System) string {
	id := string(sys.ID())
	switch strings.TrimSpace(id) {
	case "some-future-harness":
		return "a"
	}
	return ""
}`},
		{"B4", `func argv(sys System) string {
	switch strings.TrimSpace(string(sys.ID())) {
	case "some-future-harness":
		return "a"
	}
	return ""
}`},
		{"C1", `func argv(sys System) string {
	id := sys.ID()
	key := string(id)
	switch key {
	case "some-future-harness":
		return "a"
	}
	return ""
}`},
		// ---- rev2 F6 probes ----
		{"C2", `func argv(sys System) string {
	if sys.ID() == "opencode" {
		return "a"
	} else if sys.ID() == "some-future-harness" {
		return "b"
	}
	return ""
}`},
		{"C3", `func argv(sys System) string {
	id := sys.ID()
	if id == "opencode" {
		return "a"
	}
	return ""
}`},
		{"C4", `func argv(sys System) string {
	id := sys.ID()
	if id == "codex" {
		return "a"
	}
	return ""
}`},
		// ---- F6 brief-named: switch through single-assignment local, future id ----
		{"F6switch", `func argv(sys System) string {
	id := sys.ID()
	switch id {
	case "opencode":
		return "a"
	}
	return ""
}`},
		// ---- emptiness carve-out ----
		{"EMPTY-call", `func argv(sys System) string {
	if sys.ID() == "" {
		return "a"
	}
	return ""
}`},
		{"EMPTY-local", `func argv(sys System) string {
	id := sys.ID()
	if id == "" {
		return "a"
	}
	return ""
}`},
		{"EMPTY-ne", `func argv(sys System) string {
	id := sys.ID()
	if id != "" {
		return "a"
	}
	return ""
}`},
		{"TWO-IDS", `func argv(a System, b System) string {
	if a.ID() == b.ID() {
		return "x"
	}
	return ""
}`},
	}
	for _, c := range cases {
		reviewerProbe(t, c.label, probeHead+c.body+"\n")
	}
}
