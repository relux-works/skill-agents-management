package agentic

import (
	"fmt"
	"testing"
)

func atk(t *testing.T, label, src string) {
	t.Helper()
	vs, err := scanSingleSource(
		map[string]string{"pkg/launcher/a.go": src},
		map[string]bool{"pkg/agentic/registry.go": true},
	)
	if err != nil {
		fmt.Printf("ATK %-24s -> PARSE ERROR: %v\n", label, err)
		return
	}
	if len(vs) == 0 {
		fmt.Printf("ATK %-24s -> UNCAUGHT\n", label)
		return
	}
	fmt.Printf("ATK %-24s -> CAUGHT: [%s] %s\n", label, vs[0].Class, vs[0].Detail)
}

const ahead = `package launcher

import "strings"

var _ = strings.TrimSpace

type SystemID = string

type System interface{ ID() SystemID }

type builder func() []string

`

func TestReviewerAttacks(t *testing.T) {
	cases := []struct{ label, body string }{
		{"tagless-switch", `func argv(sys System) []string {
	switch {
	case sys.ID() == "opencode":
		return nil
	}
	return nil
}`},
		{"if-init-define", `func argv(sys System) []string {
	if x := sys.ID(); x == "opencode" {
		return nil
	}
	return nil
}`},
		{"return-comparison", `func isIt(sys System) bool { return sys.ID() == "opencode" }`},
		{"assign-comparison", `func argv(sys System) []string {
	ok := sys.ID() == "opencode"
	_ = ok
	return nil
}`},
		{"equalfold", `func argv(sys System) []string {
	if strings.EqualFold(string(sys.ID()), "opencode") {
		return nil
	}
	return nil
}`},
		{"hasprefix", `func argv(sys System) []string {
	if strings.HasPrefix(string(sys.ID()), "opencode") {
		return nil
	}
	return nil
}`},
		{"slice-membership", `func argv(sys System) []string {
	for _, want := range []SystemID{"opencode", "some-future-harness"} {
		if sys.ID() == want {
			return nil
		}
	}
	return nil
}`},
		{"struct-field-table", `type reg struct{ byID map[SystemID]builder }`},
		{"slice-of-pairs", `type pair struct {
	id SystemID
	b  builder
}

var shadow = []pair{{id: "opencode", b: nil}}`},
		{"typeswitch-none", `func argv(sys System) []string {
	switch sys.(type) {
	case nil:
		return nil
	}
	return nil
}`},
		{"const-id-cmp", `const openID SystemID = "opencode"

func argv(sys System) []string {
	if sys.ID() == openID {
		return nil
	}
	return nil
}`},
		{"var-id-cmp-local", `func argv(sys System) []string {
	id := sys.ID()
	want := "opencode"
	if id == want {
		return nil
	}
	return nil
}`},
	}
	for _, c := range cases {
		atk(t, c.label, ahead+c.body+"\n")
	}
}

func TestReviewerAttacks2(t *testing.T) {
	cases := []struct{ label, body string }{
		{"local-const-cmp", `func argv(sys System) []string {
	const want = "opencode"
	if sys.ID() == want {
		return nil
	}
	return nil
}`},
		{"local-var-cmp", `func argv(sys System) []string {
	var want = "opencode"
	if sys.ID() == want {
		return nil
	}
	return nil
}`},
		{"local-define-cmp", `func argv(sys System) []string {
	want := "opencode"
	if sys.ID() == want {
		return nil
	}
	return nil
}`},
		{"pkg-var-cmp", `var want = "opencode"

func argv(sys System) []string {
	if sys.ID() == want {
		return nil
	}
	return nil
}`},
		{"local-const-switch-known", `func argv(sys System) []string {
	const want = "codex"
	switch sys.ID() {
	case want:
		return nil
	}
	return nil
}`},
		{"local-var-table", `func boot() map[string]builder {
	var k = "opencode"
	return map[string]builder{k: nil}
}`},
	}
	for _, c := range cases {
		atk(t, c.label, ahead+c.body+"\n")
	}
}

func TestReviewerAttacks3(t *testing.T) {
	cases := []struct{ label, body string }{
		{"pkgvar-table-known", `var k = "codex"

var shadow = map[string]builder{k: nil}`},
		{"localvar-table-known", `func boot() map[string]builder {
	var k = "codex"
	return map[string]builder{k: nil}
}`},
		{"pkgconst-table-known", `const k = "codex"

var shadow = map[string]builder{k: nil}`},
		{"pkgvar-cmp-known", `var want = "codex"

func argv(sys System) []string {
	if sys.ID() == want {
		return nil
	}
	return nil
}`},
		{"localvar-cmp-known", `func argv(sys System) []string {
	var want = "codex"
	if sys.ID() == want {
		return nil
	}
	return nil
}`},
		{"slice-of-pairs-known", `type pair struct {
	id SystemID
	b  builder
}

var shadow = []pair{{id: "codex", b: nil}}`},
		{"equalfold-known", `func argv(sys System) []string {
	if strings.EqualFold(string(sys.ID()), "codex") {
		return nil
	}
	return nil
}`},
	}
	for _, c := range cases {
		atk(t, c.label, ahead+c.body+"\n")
	}
}
