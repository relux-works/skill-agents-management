package agentic

import (
	"fmt"
	"testing"
)

func proseProbe(t *testing.T, label, src string) {
	t.Helper()
	vs, err := scanSingleSource(
		map[string]string{"pkg/launcher/p.go": src},
		map[string]bool{"pkg/agentic/registry.go": true},
	)
	if err != nil {
		fmt.Printf("PROSE %-22s -> PARSE ERROR: %v\n", label, err)
		return
	}
	if len(vs) == 0 {
		fmt.Printf("PROSE %-22s -> UNCAUGHT\n", label)
		return
	}
	for _, v := range vs {
		fmt.Printf("PROSE %-22s -> CAUGHT: [%s] %s\n", label, v.Class, v.Detail)
	}
}

const head = `package launcher

import "strings"

var _ = strings.TrimSpace

type SystemID = string

type System interface{ ID() SystemID }

type builder func() []string

`

func TestReviewerProseClaims(t *testing.T) {
	cases := []struct{ label, body string }{
		// CLAIM: "One hop plus ANY NUMBER of one-argument calls resolves."
		{"hop1-calls2-tag", `func argv(sys System) []string {
	id := strings.TrimSpace(string(sys.ID()))
	switch strings.ToLower(strings.TrimSpace(id)) {
	case "some-future-harness":
		return nil
	}
	return nil
}`},
		{"hop1-calls3-cmp", `func argv(sys System) []string {
	id := strings.ToLower(strings.TrimSpace(string(sys.ID())))
	if strings.TrimSpace(strings.ToLower(id)) == "some-future-harness" {
		return nil
	}
	return nil
}`},

		// CLAIM (first three residuals): structural rules untouched.
		// Residual 1 shape, but the table typed map[SystemID]builder.
		{"struct-vs-callwrapped", `var shadow = map[SystemID]builder{string([]byte("claude-code")): nil}`},
		// Residual 2 shape, cross-package selector, typed table.
		{"struct-vs-crosspkg", `var shadow = map[SystemID]builder{ids.Codex: nil}

var ids struct{ Codex SystemID }`},
		// Residual 3 shape, runtime assembly, typed table.
		{"struct-vs-runtime", `func boot(parts []string) map[SystemID]builder {
	table := map[SystemID]builder{}
	table[strings.Join(parts, "-")] = nil
	return table
}`},

		// CLAIM (last three residuals): "Only the vocabulary net can fire
		// there, and only for an id this file already knows."
		{"vocab-rewritten-known", `func fold(id string) string { return id }

func argv(sys System) []string {
	id := string(sys.ID())
	id = fold(id)
	switch id {
	case "codex":
		return nil
	}
	return nil
}`},
		{"vocab-multihop-known", `func argv(sys System) []string {
	raw := sys.ID()
	id := raw
	switch id {
	case "codex":
		return nil
	}
	return nil
}`},
		{"vocab-multihopconv-known", `func argv(sys System) []string {
	id := sys.ID()
	key := string(id)
	if key == "codex" {
		return nil
	}
	return nil
}`},
		{"vocab-helper-known", `func tag(sys System) string { return string(sys.ID()) }

func argv(sys System) []string {
	switch tag(sys) {
	case "codex":
		return nil
	}
	return nil
}`},

		// Over-catch probe: a name shadowed inside a nested closure, bound to a
		// literal, inherits the parent's resolution.
		{"shadow-in-funclit", `func argv(sys System) []string {
	id := sys.ID()
	_ = id
	f := func() []string {
		id := "not-an-id-at-all"
		if id == "some-future-harness" {
			return nil
		}
		return nil
	}
	return f()
}`},
		// Control for the above: no ID() anywhere.
		{"shadow-control", `func argv() []string {
	id := "not-an-id-at-all"
	if id == "some-future-harness" {
		return nil
	}
	return nil
}`},

		// Ordinary-code surface the widened comparison rule now touches.
		{"fp-const-cmp", `const marker = "ready"

func argv(sys System) []string {
	id := sys.ID()
	_ = id
	if marker == "ready" {
		return nil
	}
	return nil
}`},
		{"fp-switch-on-mode", `func argv(sys System, mode string) []string {
	id := sys.ID()
	_ = id
	switch mode {
	case "exec":
		return nil
	}
	return nil
}`},
	}
	for _, c := range cases {
		proseProbe(t, c.label, head+c.body+"\n")
	}
}
