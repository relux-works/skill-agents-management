package agentic

import (
	"errors"
	"fmt"
	"testing"
)

// flipper is the reviewer's own unstable plugin, independent of the double the
// producer's tests use. It answers `first` on call 1 and `later` afterwards.
type flipper struct {
	first, later SystemID
	n            int
}

func (f *flipper) ID() SystemID {
	f.n++
	if f.n == 1 {
		return f.first
	}
	return f.later
}
func (f *flipper) Capabilities() Capabilities {
	return Capabilities{
		LaunchModes:     []LaunchMode{LaunchModeExec},
		EffortTransport: EffortTransportNone,
		DefaultHome:     "~/.flip",
		AuthHint:        "flip auth",
	}
}
func (f *flipper) ResolveBinary(LaunchRequest) (string, error) { return "/bin/flip", nil }
func (f *flipper) Argv(LaunchRequest, LaunchMode) ([]string, error) {
	return []string{"run"}, nil
}
func (f *flipper) ChildEnv(parent []string, _ LaunchRequest) ([]string, error) { return parent, nil }
func (f *flipper) Stdin(LaunchRequest) (StdinPayload, error)                   { return StdinPayload{}, nil }
func (f *flipper) ValidateComposition(c Composition) error                     { return nil }

func TestReviewerF7Probe(t *testing.T) {
	// P3, my rev2 spelling: unstable plugin, lowercase first then capitalized.
	r := NewRegistry()
	f := &flipper{first: "pangolin2", later: "Pangolin2"}
	err := r.Register(f)
	fmt.Printf("F7 P3 Register(unstable) err=%v is(ErrUnstableSystemID)=%v\n", err, errors.Is(err, ErrUnstableSystemID))
	fmt.Printf("F7 P3 registry IDs=%v Len=%d\n", r.IDs(), r.Len())
	for _, s := range []SystemID{"pangolin2", "Pangolin2"} {
		_, ok := r.Lookup(s)
		fmt.Printf("F7 P3 Lookup(%q) ok=%v\n", s, ok)
	}
	// P4: does the planner see it?
	p, perr := BuildPlan(r, LaunchRequest{System: "pangolin2", Model: Model{ID: "m"}}, LaunchModeExec)
	fmt.Printf("F7 P4 BuildPlan System=%q err=%v\n", p.System, perr)

	// Third-call flip: consistent through registration, changes on call 3.
	// This is the residual the docstring now declares.
	r2 := NewRegistry()
	f2 := &flipper{first: "pangolin3", later: "pangolin3"}
	err2 := r2.Register(f2)
	f2.later = "Pangolin3"
	f2.n = 99
	fmt.Printf("F7 THIRD-CALL Register err=%v ; registry key=%v ; plugin now answers %q\n", err2, r2.IDs(), f2.ID())

	// A plugin that never agrees with itself at all.
	r3 := NewRegistry()
	f3 := &flipper{first: "aaa", later: "bbb"}
	fmt.Printf("F7 NEVER-AGREES err=%v\n", r3.Register(f3))
}
