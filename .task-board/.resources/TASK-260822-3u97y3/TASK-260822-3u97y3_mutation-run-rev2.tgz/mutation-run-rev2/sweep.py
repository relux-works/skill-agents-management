import subprocess, sys, shutil, os

ROOT="/Users/alexis/src/relux-works/skill-agents-management/.temp/STORY-260821-1xppz3/worktree"
COMP=os.path.join(ROOT,"pkg/agentic/systems/claude/composition.go")
CL=os.path.join(ROOT,"pkg/agentic/systems/claude/claude.go")

MUTANTS = [
 ("M1 unknown-server refusal removed", COMP,
  '\t\tserver, exists := servers[name]\n\t\tif !exists {\n\t\t\treturn fmt.Errorf("claude composition references unknown MCP server")\n\t\t}\n',
  '\t\tserver := servers[name]\n\t\t_ = name\n'),
 ("M2 duplicate refusal removed", COMP,
  '\t\tif _, duplicate := servers[server.Name]; duplicate {\n\t\t\treturn fmt.Errorf("claude composition declares the MCP server %q twice", server.Name)\n\t\t}\n',
  ''),
 ("M3 unnamed-server refusal removed", COMP,
  '\t\tif strings.TrimSpace(server.Name) == "" {\n\t\t\treturn fmt.Errorf("claude composition carries an unnamed MCP server")\n\t\t}\n',
  ''),
 ("M4 entry.Type vs metadata transport dropped", COMP,
  'if err := decodeStrictJSON(string(raw), &entry); err != nil || entry.Type != server.Transport {',
  'if err := decodeStrictJSON(string(raw), &entry); err != nil {'),
 ("M5 http empty-url allowed", COMP,
  'if strings.TrimSpace(entry.URL) == "" || entry.Command != "" || len(entry.Args) != 0 {',
  'if entry.Command != "" || len(entry.Args) != 0 {'),
 ("M6 http args allowed", COMP,
  'if strings.TrimSpace(entry.URL) == "" || entry.Command != "" || len(entry.Args) != 0 {',
  'if strings.TrimSpace(entry.URL) == "" || entry.Command != "" {'),
 ("M7 http command allowed", COMP,
  'if strings.TrimSpace(entry.URL) == "" || entry.Command != "" || len(entry.Args) != 0 {',
  'if strings.TrimSpace(entry.URL) == "" || len(entry.Args) != 0 {'),
 ("M8 stdio url allowed", COMP,
  'if strings.TrimSpace(entry.Command) == "" || entry.URL != "" || len(entry.Headers) != 0 {',
  'if strings.TrimSpace(entry.Command) == "" || len(entry.Headers) != 0 {'),
 ("M9 stdio headers allowed", COMP,
  'if strings.TrimSpace(entry.Command) == "" || entry.URL != "" || len(entry.Headers) != 0 {',
  'if strings.TrimSpace(entry.Command) == "" || entry.URL != "" {'),
 ("M10 stdio empty-command allowed", COMP,
  'if strings.TrimSpace(entry.Command) == "" || entry.URL != "" || len(entry.Headers) != 0 {',
  'if entry.URL != "" || len(entry.Headers) != 0 {'),
 ("M11 headers-without-declared-bearer allowed", COMP,
  '\t\t\t\tif len(entry.Headers) != 0 {\n\t\t\t\t\treturn fmt.Errorf("unexpected claude HTTP headers")\n\t\t\t\t}\n',
  ''),
 ("M12 extra headers beside bearer allowed", COMP,
  'if len(entry.Headers) != 1 || entry.Headers["Authorization"] != expected {',
  'if entry.Headers["Authorization"] != expected {'),
 ("M13 nil mcpServers allowed", COMP,
  'if err := decodeStrictJSON(prefix[1], &root); err != nil || root.MCPServers == nil || len(root.MCPServers) != len(servers) {',
  'if err := decodeStrictJSON(prefix[1], &root); err != nil || len(root.MCPServers) != len(servers) {'),
 ("M14 entry-count mismatch allowed", COMP,
  'if err := decodeStrictJSON(prefix[1], &root); err != nil || root.MCPServers == nil || len(root.MCPServers) != len(servers) {',
  'if err := decodeStrictJSON(prefix[1], &root); err != nil || root.MCPServers == nil {'),
 ("M15 second top-level argument allowed", COMP,
  'if len(prefix) != 2 || prefix[0] != mcpConfigFlag {',
  'if prefix[0] != mcpConfigFlag {'),
 ("M16 wrong flag allowed", COMP,
  'if len(prefix) != 2 || prefix[0] != mcpConfigFlag {',
  'if len(prefix) != 2 {'),
 ("M17 metadata-without-config-argument allowed", COMP,
  '\t\treturn fmt.Errorf("claude MCP metadata has no config argument")\n',
  '\t\treturn nil\n'),
 ("M18a HomeEnvVar moved only", CL,
  'HomeEnvVar:  "CLAUDE_CONFIG_DIR",',
  'HomeEnvVar:  "CLAUDE_HOME",'),
 ("M18b DefaultHome moved only", CL,
  'DefaultHome: "~/.claude",',
  'DefaultHome: "~/.config/claude",'),
 ("M18c model trim dropped", os.path.join(ROOT,"pkg/agentic/systems/claude/args.go"),
  '"--model", strings.TrimSpace(req.Model.ID))',
  '"--model", req.Model.ID)'),
 ("M18 HomeEnvVar/DefaultHome moved", CL,
  'HomeEnvVar:  "CLAUDE_CONFIG_DIR",\n\t\tDefaultHome: "~/.claude",',
  'HomeEnvVar:  "CLAUDE_HOME",\n\t\tDefaultHome: "~/.config/claude",'),
]

def run():
    p = subprocess.run(["go","test","-mod=mod","./...","-count=1"], cwd=ROOT,
                       capture_output=True, text=True,
                       env={k:v for k,v in os.environ.items() if k!="TASK_BOARD_DIR"})
    return p.returncode, p.stdout+p.stderr

results=[]
for name, path, old, new in MUTANTS:
    src=open(path).read()
    if old not in src:
        results.append((name,"NOT-APPLIED (anchor missing)",""))
        continue
    bak=src
    open(path,"w").write(src.replace(old,new,1))
    code,out=run()
    open(path,"w").write(bak)
    fails=[l for l in out.splitlines() if l.startswith("--- FAIL") or l.startswith("FAIL")]
    results.append((name, "CAUGHT" if code!=0 else "SURVIVED", "; ".join(fails[:4])))
    print(f"{results[-1][1]:9} {name}  {results[-1][2][:180]}", flush=True)

print("\n=== SURVIVORS ===")
for n,s,d in results:
    if s!="CAUGHT": print(f"{s}: {n}")
