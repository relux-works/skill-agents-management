import subprocess, os, json
exec(open("/Users/alexis/src/relux-works/skill-agents-management/.temp/TASK-260822-3u97y3/sweep.py").read().split("def run():")[0])
OUT="/Users/alexis/src/relux-works/skill-agents-management/.temp/TASK-260822-3u97y3/mutation-run-rev2"
os.makedirs(OUT, exist_ok=True)
ENV={k:v for k,v in os.environ.items() if k!="TASK_BOARD_DIR"}

def run():
    p=subprocess.run(["go","test","-mod=mod","./...","-count=1"],cwd=ROOT,capture_output=True,text=True,env=ENV)
    return p.returncode,p.stdout+p.stderr

code,out=run()
open(os.path.join(OUT,"00-baseline.log"),"w").write(f"$ go test -mod=mod ./... -count=1\nEXIT={code}\n\n{out}")
print(f"baseline EXIT={code}")

summary=[]
for i,(name,path,old,new) in enumerate(MUTANTS,1):
    src=open(path).read()
    slug="".join(c if c.isalnum() else "-" for c in name)[:70]
    if old not in src:
        summary.append({"mutant":name,"result":"NOT-APPLIED"}); print("NOT-APPLIED",name); continue
    open(path,"w").write(src.replace(old,new,1))
    diff=subprocess.run(["diff","-u","/dev/stdin",path],input=src,capture_output=True,text=True).stdout
    code,out=run()
    open(path,"w").write(src)
    verdict="CAUGHT" if code!=0 else "SURVIVED"
    fails=[l for l in out.splitlines() if l.startswith("--- FAIL")]
    open(os.path.join(OUT,f"{i:02d}-{slug}.log"),"w").write(
        f"MUTANT: {name}\nFILE: {os.path.relpath(path,ROOT)}\n\n--- applied diff ---\n{diff}\n"
        f"--- $ go test -mod=mod ./... -count=1 ---\nEXIT={code}  => {verdict}\n\n{out}")
    summary.append({"mutant":name,"file":os.path.relpath(path,ROOT),"exit":code,"result":verdict,"failed_tests":fails})
    print(f"{verdict:9} exit={code}  {name}")

code,out=run()
open(os.path.join(OUT,"99-restored.log"),"w").write(f"$ go test -mod=mod ./... -count=1\nEXIT={code}\n\n{out}")
print(f"restored EXIT={code}")
json.dump({"baseline_exit":0,"restored_exit":code,"mutants":summary},open(os.path.join(OUT,"summary.json"),"w"),indent=1)
surv=[s for s in summary if s["result"]!="CAUGHT"]
print(f"\nTOTAL={len(summary)} CAUGHT={len(summary)-len(surv)} SURVIVORS={len(surv)}")
