#!/usr/bin/env python3
"""Narrow every claude gate one at a time and confirm the suite goes red.

A green suite means nothing unless something in it would have failed. This
harness weakens ONE piece of production code per run, records the real exit
code and the tests that failed, and restores the file byte-for-byte before the
next mutant. It is not a coverage tool: each mutant is a defect a port could
plausibly ship, and the test that catches it is named in the log.

Usage:
    python3 .temp/TASK-260822-3u97y3/mutants.py [--out DIR]

Exit status is 0 when EVERY mutant was caught. A mutant the suite admits is
reported as UNCAUGHT and fails the run — that is the finding, not an error.
"""

import argparse
import filecmp
import pathlib
import shutil
import subprocess
import sys
import tempfile

ROOT = pathlib.Path(__file__).resolve().parents[2]
CLAUDE = "pkg/agentic/systems/claude"

# (name, file, old, new, why). `old` must appear exactly once.
MUTANTS = [
    (
        "prefix-strip",
        f"{CLAUDE}/env.go",
        '\tenv := environ\n\tfor _, key := range runtimeEnvKeys {\n\t\tenv = agentic.SetEnvValue(env, key, "")\n\t}\n\treturn env',
        '\tout := make([]string, 0, len(environ))\n\tfor _, entry := range environ {\n\t\tblocked := false\n\t\tfor _, key := range runtimeEnvKeys {\n\t\t\tif len(entry) >= len(key) && entry[:len(key)] == key {\n\t\t\t\tblocked = true\n\t\t\t}\n\t\t}\n\t\tif !blocked {\n\t\t\tout = append(out, entry)\n\t\t}\n\t}\n\treturn out',
        "strip CLAUDECODE by PREFIX instead of by whole key; over-strips CLAUDECODE_LIKE_BUT_NOT",
    ),
    (
        "no-strip-at-all",
        f"{CLAUDE}/env.go",
        "var runtimeEnvKeys = []string{sessionMarkerEnv}",
        "var runtimeEnvKeys = []string{}",
        "the child inherits the parent's session marker and Claude Code refuses to start",
    ),
    (
        "goal-condition-refusal-dropped",
        f"{CLAUDE}/goal.go",
        '\tcondition := strings.TrimSpace(goal.ProviderCondition)\n\tif condition == "" {\n\t\treturn "", fmt.Errorf("claude: goal %q carries no provider condition; a `%s` directive with nothing after it binds the child to nothing", goal.ID, strings.TrimSpace(goalDirectivePrefix))\n\t}\n\treturn goalDirectivePrefix + condition, nil',
        "\tcondition := strings.TrimSpace(goal.ProviderCondition)\n\treturn goalDirectivePrefix + condition, nil",
        "a goal-bound launch ships a bare `/goal ` and binds the child to nothing",
    ),
    (
        "goal-mode-also-streams-stdin",
        f"{CLAUDE}/claude.go",
        "\tif req.Goal != nil {\n\t\treturn agentic.StdinPayload{}, nil\n\t}\n",
        "",
        "the goal-bound child receives the assignment twice: as system context and as its user turn",
    ),
    (
        "placeholder-binary",
        f"{CLAUDE}/binary.go",
        "\treturn launchenv.LookPath(env, executableName)",
        "\t_ = env\n\treturn executableName, nil",
        "the source's own BuildArgs bug: a display placeholder that never resolves the launch target",
    ),
    (
        "assignment-file-refusal-dropped",
        f"{CLAUDE}/args.go",
        '\t\tif mode != agentic.LaunchModeDryRun {\n\t\t\treturn nil, fmt.Errorf("claude: goal-bound launch requires an assignment prompt file")\n\t\t}\n\t\tassignmentPath = promptFilePlaceholder',
        "\t\tassignmentPath = promptFilePlaceholder",
        "a real launch names a system-prompt file that does not exist, using the dry run's placeholder",
    ),
    (
        "budget-flag-dropped",
        f"{CLAUDE}/args.go",
        '\t\targs = append(args, "--max-budget-usd", fmt.Sprintf("%.2f", req.Budget.USD))',
        "\t\t_ = req.Budget",
        "a declared capability that does not reproduce: the configured spend ceiling never reaches the child",
    ),
    (
        "composition-prefix-not-copied",
        f"{CLAUDE}/args.go",
        "\treturn append([]string{}, req.Composition.Prefix...)",
        "\treturn req.Composition.Prefix",
        "the plugin appends through into its caller's backing array",
    ),
    (
        "composition-second-argument-admitted",
        f"{CLAUDE}/composition.go",
        "\tif len(prefix) != 2 || prefix[0] != mcpConfigFlag {",
        "\tif len(prefix) < 2 || prefix[0] != mcpConfigFlag {",
        "a reviewed MCP composition can smuggle a top-level flag past the validator",
    ),
    (
        "composition-trailing-json-admitted",
        f"{CLAUDE}/composition.go",
        '\tvar trailing any\n\tif err := decoder.Decode(&trailing); !errors.Is(err, io.EOF) {\n\t\treturn fmt.Errorf("trailing JSON content")\n\t}\n\treturn nil',
        "\tvar trailing any\n\t_ = decoder.Decode(&trailing)\n\t_, _ = errors.Is(nil, io.EOF), io.EOF\n\treturn nil",
        "a second JSON document after the validated one reaches the child unchecked",
    ),
    (
        "second-argv-construction-site",
        "pkg/agentic/mutant_second_site.go",
        None,
        'package agentic\n\n// TEMPORARY MUTANT.\nfunc mutantSecondClaudeSite(effort string) []string {\n\treturn []string{"--effort", effort}\n}\n',
        "a second place claude CLI flags are spelled, one package over",
    ),
    (
        "shadow-binding-table",
        f"{CLAUDE}/mutant_shadow_table.go",
        None,
        'package claude\n\nimport "github.com/relux-works/skill-agents-management/pkg/agentic"\n\n// TEMPORARY MUTANT.\nvar mutantShadow = map[agentic.SystemID]string{}\n',
        "a second SystemID binding outside the registry",
    ),
]

SUITE = ["go", "test", "-mod=mod", "./...", "-count=1"]


def run_suite():
    completed = subprocess.run(
        SUITE, cwd=ROOT, capture_output=True, text=True,
        env={**__import__("os").environ, "TASK_BOARD_DIR": ""},
    )
    return completed.returncode, completed.stdout + completed.stderr


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", default=str(pathlib.Path(__file__).parent))
    args = parser.parse_args()
    out = pathlib.Path(args.out)
    out.mkdir(parents=True, exist_ok=True)

    code, baseline = run_suite()
    (out / "mutants-baseline.log").write_text(baseline)
    if code != 0:
        print(f"BASELINE IS RED (exit {code}); every mutant below would be meaningless")
        return 1

    failures = []
    for name, relpath, old, new, why in MUTANTS:
        path = ROOT / relpath
        created = old is None
        backup = None
        if created:
            path.write_text(new)
        else:
            with tempfile.NamedTemporaryFile(delete=False, suffix=".go") as handle:
                backup = pathlib.Path(handle.name)
            shutil.copy2(path, backup)
            body = path.read_text()
            if body.count(old) != 1:
                print(f"SKIP {name}: the anchor appears {body.count(old)} times, not once")
                failures.append(name)
                backup.unlink()
                continue
            path.write_text(body.replace(old, new))

        code, log = run_suite()
        (out / f"mutants-{name}.log").write_text(
            f"# mutant: {name}\n# defect: {why}\n# file: {relpath}\n# exit: {code}\n\n{log}"
        )

        if created:
            path.unlink()
        else:
            shutil.copy2(backup, path)
            if not filecmp.cmp(backup, path, shallow=False):
                print(f"RESTORE FAILED for {relpath}")
                return 1
            backup.unlink()

        caught = [line for line in log.splitlines() if line.startswith("--- FAIL") or line.startswith("    --- FAIL")]
        if code == 0:
            print(f"UNCAUGHT  {name:38s} exit=0  — {why}")
            failures.append(name)
        else:
            first = caught[0].strip() if caught else "(build failure)"
            print(f"caught    {name:38s} exit={code}  {first}")

    code, restored = run_suite()
    (out / "mutants-restored.log").write_text(restored)
    if code != 0:
        print(f"THE TREE DID NOT COME BACK GREEN (exit {code})")
        return 1

    if failures:
        print(f"\n{len(failures)} mutant(s) the suite admits: {', '.join(failures)}")
        return 1
    print(f"\nall {len(MUTANTS)} mutants caught; tree restored green")
    return 0


if __name__ == "__main__":
    sys.exit(main())
